// The package doc comment
package initial

import (
	"fmt"

	"domain.name/importdecl"
)

type t int

const c = 1

func foo() {
	fmt.Println(importdecl.F())
}

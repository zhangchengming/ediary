package aliaslib

type T int

func (T) Method(x *int) *int

func F()

const C = 3

var V = 0
